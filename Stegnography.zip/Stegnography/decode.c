/* Documentation
Name:        Shaik Shajara Sharikha
Date:        12/11/2019
Description: Decode the secret message from the LSB of every byte of an image in order to extract the secret message
*/

#include <stdio.h>
#include "encode.h"
#include "common.h"
#include "types.h"
#include <string.h>

/* Function Definitions */

/* Check operation type */
OperationType check_operation_type(char *argv[] )
{
    if ( argv[1] == NULL )
    {
	printf("ERROR: Argument 1 is not passed\nArguments for Decode Must Contain: ./a.out -d stego.bmp secret.txt\n");
	return e_unsupported;
    }
    else if ( strcmp(argv[1],"-e") == 0 )
    {
	printf("INFO: Encode operation detected\n");
	return e_encode;
    }
    else if ( strcmp(argv[1], "-d") == 0 )
    {
	printf("INFO: Decode operation detected\n");
	return e_decode;
    }
    else
    {
	printf("ERROR: Invalid arguments passed\nArguments for Decode Must Contain: ./a.out -d stego.bmp secret.txt\n");
	return e_unsupported;
    }
}

/* Read and validate Encode args from argv */
Status read_and_validate_decode_args(char *argv[],EncodeInfo *encInfo )
{
    if (  argv[2] )
    {
	encInfo->fptr_stego_image = fopen ( argv[2], "r" );
	if ( encInfo->fptr_stego_image == NULL )
	{
	    fprintf(stderr, "ERROR: %s Stego image is not present\n",argv[2] );
	    return e_failure;
	}
	else
	{
	    printf("INFO: Stego image %s detected\n", argv[2]);
	}
    }
    else
    {
	printf("ERROR: Argument 2 is not passed\nArguments for Decode Must Contain: ./a.out -d stego.bmp secret.txt\n");
	return e_failure;
    }
    if ( argv[3] )
    {
	encInfo->fptr_secret = fopen ( argv[3], "w" );
	if ( encInfo->fptr_secret == NULL )
	{
	    printf("INFO: Secret file %s is created\n", argv[3]);
	    return e_success;
	}
	else
	{
	    printf("INFO: Secret file %s detected\n", argv[3]);
	    return e_success;
	}
    }
    else
    {
	printf("INFO: Argument 3 is not passed\nINFO: Creating default file decode.txt\n");
	encInfo->fptr_secret = fopen ( "decode.txt", "w" );
	return e_success;
    }
}

/* Extract Magic String */
Status decode_magic_string( FILE *fptr_stego_image, FILE *fptr_secret)
{
    char magic_string[16];
    fseek(fptr_stego_image,54,SEEK_SET);
    decode_data_to_image( magic_string, 8, 2, fptr_secret, fptr_stego_image);
    if ( strcmp( magic_string, MAGIC_STRING ) == 0 )
	return e_success;
    else
	return e_failure;
}

/* Decode secret file size */
int decode_secret_file_size(FILE *fptr_stego_image)
{
    char ch[32];
    int size = 0;
    fread(ch, 32, 1, fptr_stego_image);
    for ( int i = 0; i < 32; i++ )
    {
	ch[i] = ch[i] & 1;
	size |= ch[i] << (32 - i - 1);
    }
    if ( size )
    return size;
    else
	return 0;
}

/* Decode secret file extenstion */
Status decode_secret_file_extn(EncodeInfo *encInfo)
{
    char file_ex[32];
    decode_data_to_image( file_ex, 8, 4 , encInfo->fptr_secret, encInfo->fptr_stego_image);
    if ( strcmp (file_ex, FILE_EXTN) == 0 )
	return e_success;
    else
	return e_failure;
}

/* Decode secret file size */
Status decode_secret_file_extn_size(EncodeInfo *encInfo)
{
    char ch[32];
    int size = 0;
    fread(ch, 32, 1, encInfo->fptr_stego_image);
    for ( int i = 0; i < 32; i++ )
    {
	ch[i] = ch[i] & 1;
	size |= ch[i] << (32 - i - 1);
    }
    if ( size == 4 )
	return e_success;
    else
	return e_failure;
}

/* Decode secret file data*/
Status decode_secret_file_data(EncodeInfo *encInfo)
  {
int size = decode_secret_file_size(encInfo->fptr_stego_image);
			if ( size == 0 )
			{
			    printf("ERROR: Secret file size is not decoded\n");
			    return e_failure;
			}
			char file_data[size];
    fseek(encInfo->fptr_secret,0L,SEEK_SET);
    decode_data_to_secret( file_data, 8, size, encInfo->fptr_secret, encInfo->fptr_stego_image);
	return e_success;
  }

/* Decode function, which does the real encoding */
Status decode_data_to_image(char *data, int size, int n_memb, FILE *fptr_secret, FILE *fptr_stego_image)
{
    char ch[100], str[100];
    for ( int j = 0; j < n_memb; j++ )
    {
	fread(ch, size, 1, fptr_stego_image);
	for ( int i = 0; i < size; i++ )
	{
	    ch[i] = ch[i] & 1;
	    str[j] |= ch[i] << (size - i - 1);
	}
    }
    for ( int i = 0; i < n_memb; i++ )
    {
	data[i] = str[i];
    }
    data[n_memb] = '\0';
}

Status decode_data_to_secret(char *data, int size, int n_memb, FILE *fptr_secret, FILE *fptr_stego_image)
{
    char ch[100], str[100] = {0};
    for ( int j = 0; j < n_memb; j++ )
    {
	fread(ch, size, 1, fptr_stego_image);
	for ( int i = 0; i < size; i++ )
	{
	    ch[i] = ch[i] & 1;
	    str[j] |= ch[i] << (size - i - 1);
	}
    }
	fwrite(str, 1, n_memb, fptr_secret);
}

int main(int argc, char *argv[])
{
    EncodeInfo encInfo;
    int operation_type = check_operation_type(argv);
    uint img_size, file_size;
    //  encInfo.src_image_fname = "beautiful.bmp";

    if ( operation_type == e_decode )
    {
	if ( read_and_validate_decode_args( argv, &encInfo) == e_success )
	{
	    encInfo.stego_image_fname=argv[2];
	    encInfo.secret_fname=argv[3];
	    if ( decode_magic_string(encInfo.fptr_stego_image, encInfo.fptr_secret) == e_failure )
	    {
		printf("ERROR: Decoded magic string is not equal\n");
		return 1;
	    }
	    else
	    {
		printf("INFO: Decoded magic string is equal\n");
		if ( decode_secret_file_extn_size(&encInfo) == e_failure )
		{
		    printf("ERROR: File extension size not decoded\n");
		    return 1;
		}
		else
		{
		    printf("INFO: File extension size is decoded\n");
		    if ( decode_secret_file_extn(&encInfo) == e_failure )
		    {
			printf("ERROR: File extension not decoded\n");
			return 1;
		    }
		    else
		    {
			printf("INFO: File extension decoded\n");
			    printf("INFO: Secret file size is decoded\n");
			    if ( decode_secret_file_data( &encInfo) == e_failure )
			      {
			      printf("ERROR: Secret file data is not decoded\n");
			      return 1;
			      }
			      else
			      {
			      printf("INFO: Secret file data is decoded\n");
			      printf("INFO: Decode Done Successfully\n");
			      fclose(encInfo.fptr_secret);
			      }
		    }
		}
	    }
	}
    }
else if ( operation_type == e_encode )
{
    printf("Start encoding\nUse gcc encode.c\n");
}
else
{
    printf("Invalid\n");
    return 1;
}

return 0;
}
