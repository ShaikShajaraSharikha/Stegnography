/* Documentation
The art and science of hiding information by embedding messages within other,  seemingly harmless messages. Many different
carrier file formats can be used, but digital images are the most popular because of their frequency on the internet.
Using bmp image file LSB bit of byte is replaced with bit of a secret message.
Name:        Shaik Shajara Sharikha
Date:        12/11/2019
Description: Encode the secret message into a LSB of every byte of an image in order to hide the secret message
*/

#include <stdio.h>
#include "encode.h"
#include "common.h"
#include "types.h"
#include <string.h>

/* Function Definitions */

/* Check operation type */
OperationType check_operation_type(char *argv[] )
{
    if ( argv[1] == NULL )
    {
	printf("ERROR: Argument 1 is not passed\nArguments for Encode Must Contain: ./a.out -e beautiful.bmp secret.txt\n");
	return e_unsupported;
    }
    else if ( strcmp(argv[1],"-e") == 0 )
    {
	printf("INFO: Encode operation detected\n");
	return e_encode;
    }
    else if ( strcmp(argv[1], "-d") == 0 )
    {
	printf("INFO: Decode operation detected\n");
	return e_decode;
    }
    else
    {
	printf("ERROR: Invalid arguments passed\nArguments for Encode Must Contain: ./a.out -e beautiful.bmp secret.txt\n");
	return e_unsupported;
    }
}

/* Read and validate Encode args from argv */
Status read_and_validate_encode_args(char *argv[],EncodeInfo *encInfo )
{
    if (  argv[2] )
    {
	encInfo->fptr_src_image = fopen ( argv[2], "r" );
	if ( encInfo->fptr_src_image == NULL )
	{
	    fprintf(stderr, "ERROR: %s Source image is not present\n",argv[2] );
	    return e_failure;
	}
	else
	{
	    printf("INFO: Source file %s detected\n", argv[2]);
	}
    }
    else
    {
	printf("ERROR: Argument 2 is not passed\nArguments for Encode Must Contain: ./a.out -e beautiful.bmp secret.txt\n");
	return e_failure;
    }
    if (  argv[3] )
    {
	encInfo->fptr_secret = fopen ( argv[3], "r" );
	if ( encInfo->fptr_secret == NULL )
	{
	    fprintf(stderr, "ERROR: %s Secret file is not present",argv[3] );
	    return e_failure;
	}
	else
	{
	    printf("INFO: Secret file %s detected\n", argv[3]);
	}
    }
    else
    {
	printf("ERROR: Argument 3 is not passed\nArguments for Encode Must Contain: ./a.out -e beautiful.bmp secret.txt\n");
	return e_failure;
    }
    if (  argv[4] )
    {
	encInfo->fptr_stego_image = fopen ( argv[4], "w" );
	if ( encInfo->fptr_stego_image == NULL )
	{
	    printf("INFO: %s Stego image file is created\n",argv[4] );
	    return e_success;
	}
	else
	{
	    printf("INFO: Stego image file %s is detected\n", argv[4]);
	    return e_success;
	}
    }
    else
    {
	printf("INFO: Stego image file encode.bmp is created\n");
	encInfo->fptr_stego_image = fopen ( "encode.bmp", "w" );
	return e_success;
    }
}

/* Perform the encoding */
Status do_encoding(EncodeInfo *encInfo);

/* Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    printf("INFO: Opening Required file\n");
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    //Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);
	return e_failure;
    }

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    //Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);
	return e_failure;
    }
    return e_success;
}

/* check capacity */
Status check_capacity ( EncodeInfo *encInfo )
{
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
    encInfo->size_secret_file = ( get_file_size(encInfo->fptr_secret) * 8 ) + ( sizeof(int) * 3 ) + 16;

    if ( encInfo->image_capacity > encInfo->size_secret_file )
    {
	printf("INFO: Procced Encoding\n");
	return e_success;
    }
    else
    {
	fprintf(stderr, "ERROR: %s doesn't have capacity to encode %s\n", encInfo->src_image_fname, encInfo->secret_fname);
	return e_failure;
    }
}

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    //    printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    //  printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* Get file size */
uint get_file_size(FILE *fptr)
{
    char ch;
    uint count = 0;
    fseek(fptr,0L,SEEK_SET);
    while ( (ch = fgetc(fptr)) != EOF )
    {
	count++;
    }
    return count;
}

/* Copy bmp image header */
Status copy_bmp_header(FILE * fptr_src_image, FILE *fptr_dest_image)
{
    fseek(fptr_src_image,0L,SEEK_SET);
    fseek(fptr_dest_image,0L,SEEK_SET);

    char ch[54];
    fread(ch, 54, 1, fptr_src_image);
    fwrite(ch, 54, 1, fptr_dest_image);
    return e_success;
}

/* Store Magic String */
Status encode_magic_string(char *magic_string, EncodeInfo *encInfo)
{
    fseek(encInfo->fptr_src_image,54,SEEK_SET);
    encode_data_to_image( magic_string, 2, encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
}

/* Encode secret file size */
/*Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    int filesize = get_file_size(encInfo->fptr_secret);
    char str[32];
    int bit;
    fread(str, 32, 1, encInfo->fptr_src_image);
    for ( int size = 31; size <= 0; size-- )
    {
	bit = (file_size >> size) & 1;
	*str = (*str & ~1) | bit;
    }
    fwrite(str, 32, 1, encInfo->fptr_stego_image);
    return e_success;
}*/

/* Encode secret file extenstion */
Status encode_secret_file_extn(char *file_extn, EncodeInfo *encInfo)
{
    encode_data_to_image( file_extn, 4 , encInfo->fptr_src_image, encInfo->fptr_stego_image);
    return e_success;
}

/* Encode secret file size */
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char ch[32], bit;
    int size = 31;
    fread(ch, 32, 1, encInfo->fptr_src_image);
    for ( int i = 0; i < 32 && size >= 0; i++ )
    {
	bit = (file_size >> size) & 1;
	size--;
	ch[i] = (ch[i] & ~1) | bit;
    }
    fwrite(ch, 32, 1, encInfo->fptr_stego_image);
    return e_success;
}

/* Encode secret file data*/
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    char ch[100];
    char p;
    int filesize = get_file_size(encInfo->fptr_secret);
    fseek(encInfo->fptr_secret,0L,SEEK_SET);
    fread(ch, filesize, 1, encInfo->fptr_secret);
    encode_data_to_image( ch, filesize ,encInfo->fptr_src_image, encInfo->fptr_stego_image);
    fwrite(ch, filesize, 1, encInfo->fptr_stego_image);
    return e_success;
}

/* Encode function, which does the real encoding */
Status encode_data_to_image(char *data, int size, FILE *fptr_src_image, FILE *fptr_stego_image)
{
    char str[8];
    for ( int i = 0; i < size; i++ )
    {
	fread(str, 8, 1, fptr_src_image);
	encode_byte_tolsb(data[i], str);
	fwrite(str, 8, 1, fptr_stego_image);
    }
}

/* Encode a byte into LSB of image data array */
Status encode_byte_tolsb(char data, char *image_buffer)
{
    int size, bit;
    for ( size = 7; size >= 0; size-- )
    {
	bit = (data >> size) & 1;
	*image_buffer = (*image_buffer & ~1) | bit;
	image_buffer++;
    }
}


/* Copy remaining image bytes from src to stego image after encoding */
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char ch[1000];
    while ( fread(ch, 1, 1, fptr_src) )
    {
	fwrite(ch, 1, 1, fptr_dest);
    }
    return e_success;
}

int main(int argc, char *argv[])
{
    EncodeInfo encInfo;
    int operation_type = check_operation_type(argv);
    uint img_size, file_size;
    if ( operation_type == e_encode )
    {
	if ( read_and_validate_encode_args( argv, &encInfo) == e_success )
	{
	    encInfo.src_image_fname=argv[2];
	    encInfo.secret_fname=argv[3];
	    encInfo.stego_image_fname=argv[4];
	    if (open_files(&encInfo) == e_failure)
	    {
		printf("ERROR: %s function failed\n", "open_files" );
		return 1;
	    }
	    else
	    {
		printf("INFO: All files are open\n");
		if ( copy_bmp_header(encInfo.fptr_src_image, encInfo.fptr_stego_image) == e_failure )
		{
		    printf("ERROR: Copying header to stego image failed\n");
		    return 1;
		}
		else
		{
		    printf("INFO: Header is successfully copied\n");
		    if ( check_capacity(&encInfo) == e_failure )
		    {
			printf("ERROR: Capacity to encode secret file is insufficient\n");
			return 1;
		    }
		    else
		    {
			printf("INFO: Capacity to encode secret file in soucre file is sufficient\n");
			printf("INFO: Proceed encoding Magic string\n");
			if ( encode_magic_string(MAGIC_STRING, &encInfo) == e_failure )
			{
			    printf("ERROR: Magic string encoding failed\n");
			    return 1;
			}
			else
			{
			    printf("INFO: Magic string encoded\n");
			    if ( encode_secret_file_size(4, &encInfo) == e_failure )
			    {
				printf("ERROR: File extension size not encoded\n");
				return 1;
			    }
			    else
			    {
				printf("INFO: File extension size is encoded\n");
				if ( encode_secret_file_extn(FILE_EXTN, &encInfo) == e_failure )
				{
				    printf("ERROR: File extension not encoded\n");
				    return 1;
				}
				else
				{
				    printf("INFO: File extension encoded\n");
				    file_size =  get_file_size(encInfo.fptr_secret);
				    if ( encode_secret_file_size( file_size, &encInfo) == e_failure )
				    {
					printf("ERROR: Secret file size is not encoded\n");
					return 1;
				    }
				    else
				    {
					printf("INFO: Secret file size is encoded\n");
					if ( encode_secret_file_data( &encInfo) == e_failure )
					{
					    printf("ERROR: Secret file data is not encoded\n");
					    return 1;
					}
					else
					{
					    printf("INFO: Secret file data is encoded\n");
					    if ( copy_remaining_img_data( encInfo.fptr_src_image, encInfo.fptr_stego_image ) == e_failure )
					    {
						printf("ERROR: Remaining data of source file is not copies\n");
						return 1;
					    }
					    else
					    {
						printf("INFO: Remaining data of source file is copied successfully\n");
						printf("INFO: Encode Done Successfully\n");
					    }
					}
				    }
				}
			    }
			}
		    }
		}
	    }
	}
    }
    else if ( operation_type == e_decode )
    {
	printf("Start decoding\nUse gcc decode.c\n");
    }
    else
    {
	printf("Invalid\n");
	return 1;
    }

    return 0;
}
